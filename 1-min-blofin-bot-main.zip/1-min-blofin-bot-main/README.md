# BTC 1-Minute BloFin Bot — History + Learning Core

This branch builds the permanent data/learning foundation for the 1-minute bot:

**ZIP bootstrap → Binance gap recovery → continuous 1m updater → SQLite historical map → TA/pattern map → multi-timeframe context → outcome labels → strategy laboratory → controlled learning.**

## What is implemented

- Resumable import of the supplied Binance 1-minute ZIP into SQLite.
- Binance overlap validation, terminal-candle finalization, missing-history recovery and continuous closed-candle updates.
- Explicit continuity checks: no synthetic candles are invented.
- 1m TA features: EMA 20/50/200, RSI, ATR, MACD, Bollinger width, ROC, volume ratio, trend/momentum/structure scores and market regime.
- Japanese candlestick recognition and price-action structure.
- Algorithmic **candidate** Elliott and harmonic interpretations. They are stored with confidence/details rather than treated as uniquely correct labels.
- Materialized 3m/5m/15m/30m/1h/4h/1d history and MTF trend/RSI/ATR context.
- Forward-return and MFE/MAE outcome labels for historical-analogue research.
- Versioned strategy DNA, walk-forward validation/test gates, champion/challenger lineage, retained failed variants and evidence-backed knowledge records.
- Trade-experience storage so losses can be tagged and accumulated as evidence instead of causing uncontrolled live self-modification.
- Independent risk governor with dynamic risk scaling, portfolio heat, daily-loss/account-drawdown/loss-streak circuit breakers, position caps, structural/ATR stops, break-even and ATR/swing trailing.

## Safety architecture

The learner never owns the wallet. Strategy variants can modify bounded signal and exit parameters, but `RiskGovernor` is a separate hard layer and cannot be overridden by a learned strategy.

A challenger is not promoted because of one profitable backtest. The engine uses chronological training, validation and untouched test sections. Promotion requires positive validation **and** test expectancy, profit factor above 1 on both, adequate sample size, and a measurable score improvement over the current champion. Failed variants remain recorded.

## Commands

    python -m btc_bot.cli --db data/btc_history.sqlite bootstrap BTCUSD_1m_Binance.zip
    python -m btc_bot.cli --db data/btc_history.sqlite repair-gaps
    python -m btc_bot.cli --db data/btc_history.sqlite sync
    python -m btc_bot.cli --db data/btc_history.sqlite verify
    python -m btc_bot.cli --db data/btc_history.sqlite features --rebuild
    python -m btc_bot.cli --db data/btc_history.sqlite mtf
    python -m btc_bot.cli --db data/btc_history.sqlite outcomes --rebuild
    python -m btc_bot.cli --db data/btc_history.sqlite learn --challengers 24
    python -m btc_bot.cli --db data/btc_history.sqlite status

The bootstrap is resumable. If a multi-million-row import is interrupted, rerunning it skips candles already present rather than starting over.

## Real-data validation performed during development

The supplied ZIP imported as **4,278,671 one-minute candles**, from **2017-08-17 04:00 UTC** through **2025-10-11 11:02 UTC**.

The source ZIP contains historical discontinuities. They are detected and preserved; `repair-gaps` asks Binance for the missing intervals and inserts only candles Binance actually returns.

The ZIP terminal 2025-10-11 11:02 candle is a provisional snapshot. The sync logic permits replacement only when Binance's finalized candle is a valid cumulative extension; older overlap mismatches abort.

A recent 150,001-minute real-data derivation produced 150,001 TA snapshots, 112,553 pattern events and 149,761 outcome labels.

The first adaptive baseline/challenger experiment on the recent research window was strongly unprofitable after assumed fees/slippage, and **no challenger was promoted**. That is desired behavior: the lab rejects strategies that do not survive validation rather than forcing a tradeable result.

## Status

This is the permanent history/research/learning core. It is not a claim of profitability. The next execution layer should connect the champion strategy to paper/demo trading only after robust historical validation, then graduate to live trading separately.
